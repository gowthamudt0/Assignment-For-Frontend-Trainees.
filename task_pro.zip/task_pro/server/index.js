
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 5000;


app.use(express.json());
const cors = require('cors');
app.use(cors());

const filePath = path.join(__dirname, './data.json');

app.get('/loadwidgetdata', (req, res) => {
  fs.readFile(filePath, 'utf8', (err, data) => {
      if (err) {
          if (err.code === 'ENOENT') {
            
              return res.json([]);
          }
          return res.status(500).json({ error: 'Failed to load widget data' });
      }
      const parsedData = JSON.parse(data);
    
      const widgets = Array.isArray(parsedData) ? parsedData : parsedData.widgets || [];
      res.json(widgets);
  });
});

app.post('/savewidgetdata', (req, res) => {
  const widgetData = req.body;
  fs.writeFile(filePath, JSON.stringify(widgetData, null, 2), (err) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to save widget data.' });
    }
    res.status(200).json({ message: 'Widget data saved successfully!' });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
