import React, { useState, useEffect } from 'react';
import Widget from './Widget'; 

const Dashboard = () => {
    const [widgets, setWidgets] = useState([]);
    useEffect(() => {
        const loadWidgetData = async () => {
            try {
                const response = await fetch('http://localhost:5000/loadwidgetdata');
                const data = await response.json();
                console.log('Fetched data:', data);
                if (Array.isArray(data)) {
                    setWidgets(data);
                } else {
                    console.error('Fetched data is not an array');
                }
            } catch (error) {
                console.error('Failed to load widget data', error);
            }
        };
        loadWidgetData();
    }, []);
    const addWidget = (type) => {
        const newWidget = { id: widgets.length + 1, type, title: `${type} Chart ${widgets.length + 1}`, data: [] };
        const updatedWidgets = [...widgets, newWidget];
        setWidgets(updatedWidgets);
        saveWidgetData(updatedWidgets);
    };
    const updateWidgetData = (id, newTitle, newData) => {
        const updatedWidgets = widgets.map(widget =>
            widget.id === id ? { ...widget, title: newTitle, data: newData } : widget
        );
        setWidgets(updatedWidgets);
        saveWidgetData(updatedWidgets);
    };
    const saveWidgetData = async (data) => {
        try {
            const response = await fetch('http://localhost:5000/savewidgetdata', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            console.log('Data saved successfully!');
        } catch (error) {
            console.error('Failed to save widget data', error);
        }
    };
    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold">Dashboard</h1>
                <div className="flex space-x-4">
                    <button 
                        className="bg-blue-500 text-white px-4 py-2 rounded"
                        onClick={() => addWidget('pie')}
                    >
                        Add Pie Chart
                    </button>
                    <button 
                        className="bg-green-500 text-white px-4 py-2 rounded"
                        onClick={() => addWidget('bar')}
                    >
                        Add Bar Chart
                    </button>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {widgets.length > 0 ? (
                    widgets.map(widget => (
                        <Widget
                            key={widget.id}
                            type={widget.type}
                            title={widget.title}
                            data={widget.data}
                            onUpdateData={(newTitle, newData) => updateWidgetData(widget.id, newTitle, newData)}
                        />
                    ))
                ) : (
                    <p>No widgets available</p>
                )}
            </div>
        </div>
    );
};

export default Dashboard;
